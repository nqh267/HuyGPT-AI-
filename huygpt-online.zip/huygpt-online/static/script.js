// ---- Simple DOM helpers ----
const $ = s => document.querySelector(s);
const chatEl = $("#chat");
const inputEl = $("#input");
const sendBtn = $("#send");
const newBtn = $("#new-chat");

// Conversation history (giống ChatGPT: user/assistant)
let history = [];

// UI: add message
function addMsg(role, text){
  const wrap = document.createElement("div");
  wrap.className = `msg ${role}`;
  const av = document.createElement("div");
  av.className = "avatar";
  av.textContent = role === "user" ? "U" : "H";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  wrap.append(av, bubble);
  chatEl.appendChild(wrap);
  chatEl.scrollTop = chatEl.scrollHeight;
}

// Send message handler
async function send(){
  const txt = inputEl.value.trim();
  if(!txt) return;
  inputEl.value = "";
  addMsg("user", txt);
  history.push({role:"user", content: txt});

  // placeholder while waiting
  const thinking = document.createElement("div");
  thinking.className = "msg assistant";
  thinking.innerHTML = `<div class="avatar">H</div><div class="bubble">Đang suy nghĩ...</div>`;
  chatEl.appendChild(thinking);
  chatEl.scrollTop = chatEl.scrollHeight;

  try{
    const res = await fetch("/api/ask", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ query: txt, history })
    });
    const data = await res.json();
    thinking.remove();
    const ans = data.answer || "(không có phản hồi)";
    addMsg("assistant", ans);
    history.push({role:"assistant", content: ans});
  }catch(e){
    thinking.remove();
    addMsg("assistant", "Có lỗi kết nối máy chủ.");
  }
}

sendBtn.addEventListener("click", send);
inputEl.addEventListener("keydown", (e)=>{ if(e.key==="Enter" && !e.shiftKey){ e.preventDefault(); send(); }});
newBtn.addEventListener("click", ()=>{
  history = [];
  chatEl.innerHTML = "";
  addMsg("assistant", "Chào bạn! Mình là HuyGPT. Hỏi mình bất cứ điều gì nhé.");
});

// ---- YouTube Music ----
const ytInput = $("#yt-input");
const ytPlay = $("#yt-play");
const ytStop = $("#yt-stop");
const ytFrame = $("#yt-player");

function toVideoId(url){
  try{
    if (url.includes("youtu.be/")) return url.split("youtu.be/")[1].split(/[?&]/)[0];
    const u = new URL(url);
    if (u.hostname.includes("youtube.com")) return u.searchParams.get("v");
    return url; // cho phép dán thẳng ID
  }catch{ return null; }
}
ytPlay.addEventListener("click", ()=>{
  const vid = toVideoId(ytInput.value.trim());
  if(!vid) return alert("Link YouTube không hợp lệ");
  ytFrame.src = `https://www.youtube.com/embed/${vid}?autoplay=1&loop=1&playlist=${vid}`;
});
ytStop.addEventListener("click", ()=>{ ytFrame.src = ""; });

// Gợi ý chào mừng
addMsg("assistant", "Chào bạn! Mình là HuyGPT. Dán link YouTube để bật nhạc nền 🎵, rồi nhập câu hỏi để mình trả lời.");