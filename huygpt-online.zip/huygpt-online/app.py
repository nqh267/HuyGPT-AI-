from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
import os, time, requests

load_dotenv()
app = Flask(__name__)

# ---- Config ----
USE_OPENAI = os.getenv("USE_OPENAI", "true").lower() == "true"
USE_GEMINI = os.getenv("USE_GEMINI", "false").lower() == "true"

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_MODEL   = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GEMINI_MODEL   = os.getenv("GEMINI_MODEL", "gemini-1.5-pro")

GOOGLE_KEY = os.getenv("GOOGLE_SEARCH_KEY")
GOOGLE_CX  = os.getenv("GOOGLE_SEARCH_CX")
GOOGLE_NUM = int(os.getenv("GOOGLE_SEARCH_NUM", "5"))

# ---- Providers init (lazy) ----
_openai_client = None
_gemini_model = None

def _try_openai(messages):
    global _openai_client
    if not (USE_OPENAI and OPENAI_API_KEY):
        return None
    try:
        if _openai_client is None:
            from openai import OpenAI
            _openai_client = OpenAI(api_key=OPENAI_API_KEY)
        resp = _openai_client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=messages,
            temperature=0.2,
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        return None

def _try_gemini(prompt):
    global _gemini_model
    if not (USE_GEMINI and GEMINI_API_KEY):
        return None
    try:
        import google.generativeai as genai
        if _gemini_model is None:
            genai.configure(api_key=GEMINI_API_KEY)
            _gemini_model = genai.GenerativeModel(GEMINI_MODEL)
        out = _gemini_model.generate_content(prompt)
        return (out.text or "").strip()
    except Exception:
        return None

def _google_search_snippets(query):
    if not (GOOGLE_KEY and GOOGLE_CX):
        return []
    try:
        r = requests.get(
            "https://www.googleapis.com/customsearch/v1",
            params={"key": GOOGLE_KEY, "cx": GOOGLE_CX, "q": query, "num": max(1, min(GOOGLE_NUM, 10)), "hl": "vi"},
            timeout=20
        )
        data = r.json()
        items = data.get("items", []) or []
        return [f"{it.get('title','')} — {it.get('link','')}\n{it.get('snippet','')}" for it in items]
    except Exception:
        return []

def _search_and_summarize(query):
    """Fallback: dùng Google Search, rồi tóm tắt bằng quy tắc đơn giản nếu không có LLM."""
    items = _google_search_snippets(query)
    if not items:
        return "Mình chưa có đủ thông tin để trả lời. Hãy thử hỏi cụ thể hơn hoặc bật API key."
    # Nếu có LLM thì nhờ LLM tóm tắt luôn
    context = "\n\n".join(items)
    prompt = f"Ngữ cảnh web:\n\"\"\"\n{context}\n\"\"\"\nCâu hỏi: {query}\nHãy tóm tắt ngắn gọn, chính xác, có gạch đầu dòng."
    ans = _try_openai([{"role":"system","content":"Bạn là HuyGPT, trả lời ngắn gọn, chính xác."},
                       {"role":"user","content": prompt}])
    if ans:
        return ans + "\n\n(Nguồn web đã tham khảo qua Google Programmable Search)"
    ans = _try_gemini(prompt)
    if ans:
        return ans + "\n\n(Nguồn web đã tham khảo qua Google Programmable Search)"
    # Không có LLM nào: trả lời rule-based
    bullets = "\n- ".join([s.split("\n")[0][:160] for s in items[:5]])
    return f"Mình đã tìm được vài nguồn:\n- {bullets}\n\n(Hãy thêm API key để mình tóm tắt chi tiết hơn!)"

@app.route("/")
def index():
    return render_template("index.html", time=int(time.time()))

@app.post("/api/ask")
def api_ask():
    payload = request.get_json(force=True)
    query = (payload.get("query") or "").strip()
    history = payload.get("history") or []   # [{role:'user'|'assistant', content:'...'}]
    if not query:
        return jsonify({"error": "empty query"}), 400

    # Chuẩn hóa lịch sử + system prompt
    sys = {"role":"system","content":"Bạn là HuyGPT. Trả lời gọn, chính xác, có thể dùng bullet, nêu bước tiếp theo khi hợp lý."}
    messages = [sys] + history + [{"role":"user","content":query}]

    # 1) OpenAI
    ans = _try_openai(messages)
    if ans:
        return jsonify({"answer": ans})

    # 2) Gemini (gộp lịch sử thành prompt đơn)
    convo = []
    for m in history:
        role = "Người dùng" if m.get("role") == "user" else "HuyGPT"
        convo.append(f"{role}: {m.get('content','')}")
    prompt = f"{sys['content']}\n\n" + "\n".join(convo) + f"\nNgười dùng: {query}\nHuyGPT:"
    ans = _try_gemini(prompt)
    if ans:
        return jsonify({"answer": ans})

    # 3) Fallback Google Search
    return jsonify({"answer": _search_and_summarize(query)})

if __name__ == "__main__":
    # Truy cập http://127.0.0.1:5000
    app.run(host="0.0.0.0", port=5000, debug=True)